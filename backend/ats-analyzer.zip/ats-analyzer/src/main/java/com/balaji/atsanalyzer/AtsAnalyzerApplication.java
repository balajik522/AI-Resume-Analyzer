package com.balaji.atsanalyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtsAnalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtsAnalyzerApplication.class, args);
	}

}
